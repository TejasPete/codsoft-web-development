Level 1 Task 3 - Calculator
![image](https://user-images.githubusercontent.com/79355266/208496671-0401fb17-86e5-4cde-ac2a-b32a875456af.png)
Test Live Calculator <a href="https://mrnitishroy.github.io/calculator/" target="_blank">Click Here </a>
